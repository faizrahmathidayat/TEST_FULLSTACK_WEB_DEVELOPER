-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2022 at 07:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bengkel_roda_maju`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `nama_customer` varchar(100) NOT NULL,
  `telp` varchar(14) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `nama_customer`, `telp`, `alamat`) VALUES
(6, 'Faiz Rahmat Hidayat', '085771855911', 'Kp. Panyembir Kec. Panongan Kab. Tangerang'),
(19, 'Syilawati', '0878683929498', 'asasas');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_layanan`
--

CREATE TABLE `jenis_layanan` (
  `id` int(11) NOT NULL,
  `id_kategori_layanan` int(11) NOT NULL,
  `jenis_layanan` varchar(100) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_layanan`
--

INSERT INTO `jenis_layanan` (`id`, `id_kategori_layanan`, `jenis_layanan`, `is_active`) VALUES
(4, 5, 'Service 10000 KM', 1),
(5, 5, 'Service 15000 KM', 1),
(6, 5, 'Service 20000 KM', 1),
(7, 5, 'Service Diatas 20000 KM', 1),
(8, 6, 'Turun Mesin', 1),
(9, 6, 'Pengecatan Ulang', 1);

-- --------------------------------------------------------

--
-- Table structure for table `kategori_layanan`
--

CREATE TABLE `kategori_layanan` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori_layanan`
--

INSERT INTO `kategori_layanan` (`id`, `nama_kategori`, `is_active`) VALUES
(5, 'Service Ringan', 1),
(6, 'Service Berat', 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'ADMIN'),
(2, 'SALES');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_booking`
--

CREATE TABLE `transaksi_booking` (
  `id` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_jenis_layanan` int(11) NOT NULL,
  `code_transaksi` varchar(100) NOT NULL,
  `jenis_kendaraan` varchar(100) NOT NULL,
  `merk_kendaraan` varchar(100) DEFAULT NULL,
  `tipe_kendaraan` varchar(100) DEFAULT NULL,
  `nopol` varchar(20) NOT NULL,
  `tgl_booking` date NOT NULL DEFAULT curdate(),
  `tgl_service` date NOT NULL,
  `status_pengerjaan` tinyint(1) DEFAULT 0,
  `created_by` varchar(100) DEFAULT 'Customer',
  `updated_by` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi_booking`
--

INSERT INTO `transaksi_booking` (`id`, `id_customer`, `id_jenis_layanan`, `code_transaksi`, `jenis_kendaraan`, `merk_kendaraan`, `tipe_kendaraan`, `nopol`, `tgl_booking`, `tgl_service`, `status_pengerjaan`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(5, 6, 4, 'TRANS-B2000ABC-1664562211', 'Sepeda Motor', 'Honda', 'Sonic 125 RS', 'B 2000 ABC', '2022-10-01', '2022-10-11', 1, 'Faiz Rahmat Hidayat', 'Faiz Rahmat Hidayat', '2022-10-01 01:23:31', '2022-10-01 11:05:22'),
(13, 19, 4, 'TRANS-B1000ABC-1664637295', 'Sepeda Motor', 'Yamaha', 'Jupiter Z 112', 'B 1000 ABC', '2022-10-01', '2022-10-04', 2, 'Customer', 'Faiz Rahmat Hidayat', '2022-10-01 22:14:55', '2022-10-01 22:16:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `roles_id`, `name`, `username`, `password`, `created_at`, `updated_at`) VALUES
(7, 1, 'admin', 'admin', '$2y$10$ZEklWolsIezxaguBGyhLhOebmF.X/gvvaWdFjJqSceJoIxNHLIYSS', '2022-10-01 17:18:07', NULL),
(8, 1, 'Faiz Rahmat Hidayat', 'faiz_rh', '$2y$10$H6o5Vi1G564qiVIg0JBhc.rvZ6XKXfDbPlvK9r3w5wMXUf9Mm80bm', '2022-10-01 17:29:56', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `view_transaksi_booking`
-- (See below for the actual view)
--
CREATE TABLE `view_transaksi_booking` (
`nama_customer` varchar(100)
,`jenis_layanan` varchar(100)
,`id` int(11)
,`id_customer` int(11)
,`id_jenis_layanan` int(11)
,`code_transaksi` varchar(100)
,`jenis_kendaraan` varchar(100)
,`merk_kendaraan` varchar(100)
,`tipe_kendaraan` varchar(100)
,`nopol` varchar(20)
,`tgl_booking` date
,`tgl_service` date
,`status_pengerjaan` tinyint(1)
,`created_by` varchar(100)
,`updated_by` varchar(100)
,`created_at` datetime
,`updated_at` datetime
);

-- --------------------------------------------------------

--
-- Structure for view `view_transaksi_booking`
--
DROP TABLE IF EXISTS `view_transaksi_booking`;

CREATE ALGORITHM=UNDEFINED DEFINER=`` SQL SECURITY DEFINER VIEW `view_transaksi_booking`  AS SELECT `c`.`nama_customer` AS `nama_customer`, `jl`.`jenis_layanan` AS `jenis_layanan`, `tb`.`id` AS `id`, `tb`.`id_customer` AS `id_customer`, `tb`.`id_jenis_layanan` AS `id_jenis_layanan`, `tb`.`code_transaksi` AS `code_transaksi`, `tb`.`jenis_kendaraan` AS `jenis_kendaraan`, `tb`.`merk_kendaraan` AS `merk_kendaraan`, `tb`.`tipe_kendaraan` AS `tipe_kendaraan`, `tb`.`nopol` AS `nopol`, `tb`.`tgl_booking` AS `tgl_booking`, `tb`.`tgl_service` AS `tgl_service`, `tb`.`status_pengerjaan` AS `status_pengerjaan`, `tb`.`created_by` AS `created_by`, `tb`.`updated_by` AS `updated_by`, `tb`.`created_at` AS `created_at`, `tb`.`updated_at` AS `updated_at` FROM ((`transaksi_booking` `tb` join `customer` `c` on(`tb`.`id_customer` = `c`.`id`)) join `jenis_layanan` `jl` on(`tb`.`id_jenis_layanan` = `jl`.`id`)) ORDER BY `tb`.`id` AS `DESCdesc` ASC  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_layanan`
--
ALTER TABLE `jenis_layanan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jenis_layanan_FK` (`id_kategori_layanan`);

--
-- Indexes for table `kategori_layanan`
--
ALTER TABLE `kategori_layanan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi_booking`
--
ALTER TABLE `transaksi_booking`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaksi_booking_FK` (`id_customer`),
  ADD KEY `transaksi_booking_FK_1` (`id_jenis_layanan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_FK` (`roles_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `jenis_layanan`
--
ALTER TABLE `jenis_layanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kategori_layanan`
--
ALTER TABLE `kategori_layanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaksi_booking`
--
ALTER TABLE `transaksi_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jenis_layanan`
--
ALTER TABLE `jenis_layanan`
  ADD CONSTRAINT `jenis_layanan_FK` FOREIGN KEY (`id_kategori_layanan`) REFERENCES `kategori_layanan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transaksi_booking`
--
ALTER TABLE `transaksi_booking`
  ADD CONSTRAINT `transaksi_booking_FK` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaksi_booking_FK_1` FOREIGN KEY (`id_jenis_layanan`) REFERENCES `jenis_layanan` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_FK` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
