<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_Users extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function AllUsers()
    {
        $this->db->select('roles.role_name, users.*');
        $this->db->from('users');
        $this->db->join('roles', 'roles.id = users.roles_id');
        $users = $this->db->get();
        return $users;
    }

    public function store($data)
    {
        return $this->db->insert('users', $data);
    }

    public function show($id)
    {
        $this->db->select('roles.role_name, users.*');
        $this->db->from('users');
        $this->db->join('roles', 'roles.id = users.roles_id');
        $this->db->where('users.id', $id);
        $query = $this->db->get();
        return $query;
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('users', $data);
    }

    public function delete($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('users');
    }
}
