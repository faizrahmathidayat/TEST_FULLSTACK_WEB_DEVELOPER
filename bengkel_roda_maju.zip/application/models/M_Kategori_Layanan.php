<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_Kategori_Layanan extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function AllKategori()
    {
        $customer = $this->db->get('kategori_layanan');
        return $customer;
    }

    public function store($data)
    {
        return $this->db->insert('kategori_layanan', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('kategori_layanan', $data);
    }
}
