<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_Jenis_layanan extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function AllJenisLayanan()
    {
        $this->db->select('jenis_layanan.id, jenis_layanan.jenis_layanan, kategori_layanan.nama_kategori');
        $this->db->from('jenis_layanan');
        $this->db->join('kategori_layanan', 'jenis_layanan.id_kategori_layanan = kategori_layanan.id');
        $query = $this->db->get();
        return $query;
    }

    public function store($data)
    {
        return $this->db->insert('jenis_layanan', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('jenis_layanan', $data);
    }
}
