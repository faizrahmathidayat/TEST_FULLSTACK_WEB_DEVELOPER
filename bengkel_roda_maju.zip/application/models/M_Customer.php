<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_Customer extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function AllCustomer()
    {
        $customer = $this->db->get('customer');
        return $customer;
    }

    public function store($data)
    {
        return $this->db->insert('customer', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('customer', $data);
    }
}
