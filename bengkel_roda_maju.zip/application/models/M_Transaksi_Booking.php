<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class M_Transaksi_Booking extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function TransaksiBooking($status_pengerjaan = null)
    {
        $transaksi_booking = $this->db->from('transaksi_booking');
        if (!is_null($status_pengerjaan))
            $transaksi_booking = $transaksi_booking->where('status_pengerjaan', $status_pengerjaan);

        return $transaksi_booking->get();
    }

    public function AllTransaksiBooking()
    {
        return $this->db->get('view_transaksi_booking');
    }

    public function store($data)
    {
        return $this->db->insert('transaksi_booking', $data);
    }

    public function update($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('transaksi_booking', $data);
    }
}
