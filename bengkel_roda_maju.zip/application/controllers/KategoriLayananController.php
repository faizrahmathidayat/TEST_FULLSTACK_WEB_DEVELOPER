<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KategoriLayananController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['auth', 'form_validation']);
        $this->auth->authenticate();
        $this->auth->route_access();
        $this->load->model('M_Kategori_Layanan');
    }

    public function rules_store()
    {
        $this->form_validation->set_rules(
            'nama_kategori',
            'Nama Kategori Layanan',
            'required',
            array(
                'required' => 'Nama Kategori Layanan Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'nama_kategori' => form_error('nama_kategori'),
            );
        }

        return $array;
    }

    public function rules_update()
    {
        $this->form_validation->set_rules(
            'edit_nama_kategori',
            'Nama Kategori Layanan',
            'required',
            array(
                'required' => 'Nama Kategori Layanan Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'nama_kategori' => form_error('edit_nama_kategori'),
            );
        }

        return $array;
    }

    public function index()
    {
        admin_template('pages/KategoriLayanan/v_kategori_layanan', null, 'pages/KategoriLayanan/js_kategori_layanan', 'Kategori Layanan');
    }

    public function getData()
    {
        $kategori_layanan = $this->M_Kategori_Layanan->AllKategori();
        echo json_encode(array('data' => $kategori_layanan->result()));
    }

    public function store()
    {
        $input = $this->input->post();
        $validate = $this->rules_store();

        if (!$validate['success']) {
            $store_kageori_layanan = $this->M_Kategori_Layanan->store($input);
            if ($store_kageori_layanan) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }

    public function show($id)
    {
        $get_kategori_layanan = $this->db->get_where('kategori_layanan', array('id' => $id));

        echo json_encode($get_kategori_layanan->row());
    }

    public function update($id)
    {
        $input = $this->input->post();
        $validate = $this->rules_update();

        $data = array(
            'nama_kategori' => $input['edit_nama_kategori']
        );

        if (!$validate['success']) {
            $update_kategori = $this->M_Kategori_Layanan->update($id, $data);
            if ($update_kategori) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }
}
