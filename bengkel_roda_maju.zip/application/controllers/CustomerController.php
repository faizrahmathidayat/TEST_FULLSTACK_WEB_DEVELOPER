<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CustomerController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['auth', 'form_validation']);
        $this->auth->authenticate();
        $this->auth->route_access();
        $this->load->model('M_Customer');
    }

    public function rules_store()
    {
        $this->form_validation->set_rules(
            'nama_customer',
            'Nama Customer',
            'required',
            array(
                'required' => 'Nama Customer Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'telp',
            'Telepon',
            'required',
            array(
                'required' => 'No Telepon Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'alamat',
            'Alamat',
            'required',
            array(
                'required' => 'Alamat Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'nama_customer' => form_error('nama_customer'),
                'telp' => form_error('telp'),
                'alamat' => form_error('alamat')
            );
        }

        return $array;
    }

    public function rules_update()
    {
        $this->form_validation->set_rules(
            'edit_nama_customer',
            'Nama Customer',
            'required',
            array(
                'required' => 'Nama Customer Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'edit_telp',
            'Telepon',
            'required',
            array(
                'required' => 'No Telepon Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'edit_alamat',
            'Alamat',
            'required',
            array(
                'required' => 'Alamat Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'nama_customer' => form_error('edit_nama_customer'),
                'telp' => form_error('edit_telp'),
                'alamat' => form_error('edit_alamat')
            );
        }

        return $array;
    }

    public function index()
    {
        admin_template('pages/Customer/v_customer', null, 'pages/Customer/js_customer', 'Customer');
    }

    public function getData()
    {
        $customer = $this->M_Customer->AllCustomer();
        echo json_encode(array('data' => $customer->result()));
    }

    public function store()
    {
        $input = $this->input->post();
        $validate = $this->rules_store();

        if (!$validate['success']) {
            $store_customer = $this->M_Customer->store($input);
            if ($store_customer) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }

    public function show($id)
    {
        $get_customer = $this->db->get_where('customer', array('id' => $id));

        echo json_encode($get_customer->row());
    }

    public function update($id)
    {
        $input = $this->input->post();
        $validate = $this->rules_update();

        $data = array(
            'nama_customer' => $input['edit_nama_customer'],
            'telp' => $input['edit_telp'],
            'alamat' => $input['edit_alamat'],
        );

        if (!$validate['success']) {
            $update_customer = $this->M_Customer->update($id, $data);
            if ($update_customer) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }
}
