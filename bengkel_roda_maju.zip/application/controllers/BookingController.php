<?php
defined('BASEPATH') or exit('No direct script access allowed');

class BookingController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('M_Customer');
        $this->load->model('M_Jenis_layanan');
        $this->load->model('M_Transaksi_Booking');
    }

    public function index()
    {
        $get_jenis_layanan = $this->M_Jenis_layanan->AllJenisLayanan();
        $data = array(
            'jenis_layanan' => $get_jenis_layanan->result()
        );
        $this->load->view('Landing/v_form_booking', $data);
    }

    public function rules_store()
    {
        $this->form_validation->set_rules(
            'customer',
            'Nama Customer',
            'required',
            array(
                'required' => 'Nama Customer Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'telp',
            'Telepon',
            'required',
            array(
                'required' => 'Telepon Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'jenis_layanan',
            'Jenis Layanan',
            'required',
            array(
                'required' => 'Jenis Layanan Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'jenis_kendaraan',
            'Jenis Kendaraan',
            'required',
            array(
                'required' => 'Jenis Kendaraan Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'merk_kendaraan',
            'Merk Kendaraan',
            'required',
            array(
                'required' => 'Merk Kendaraan Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'tipe_kendaraan',
            'Tipe Kendaraan',
            'required',
            array(
                'required' => 'Tipe Kendaraan Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'nopol',
            'No. Polisi',
            'required',
            array(
                'required' => 'No. Polisi Tidak boleh kosong.',
            )
        );

        $this->form_validation->set_rules(
            'tgl_service',
            'Tanggal Service',
            'required|callback_check_tgl_service',
            array(
                'required' => 'Tanggal Service Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'customer' => form_error('customer'),
                'telp' => form_error('telp'),
                'jenis_layanan' => form_error('jenis_layanan'),
                'jenis_kendaraan' => form_error('jenis_kendaraan'),
                'merk_kendaraan' => form_error('merk_kendaraan'),
                'tipe_kendaraan' => form_error('tipe_kendaraan'),
                'tgl_service' => form_error('tgl_service'),
                'nopol' => form_error('nopol')
            );
        }

        return $array;
    }

    public function check_tgl_service($date)
    {
        $now = strtotime(date('Y-m-d'));
        $tgl_service = strtotime($date);
        $datediff = $tgl_service - $now;

        $intervalDate = round($datediff / (60 * 60 * 24));
        if ($intervalDate > 2) {
            return TRUE;
        } else {
            $this->form_validation->set_message('check_tgl_service', 'Minimal Tanggal Service H-2 dari tanggal hari ini.');
            return FALSE;
        }
    }

    public function store()
    {
        $input = $this->input->post();
        $validate = $this->rules_store();

        $this->db->trans_begin();
        $data_customer = array(
            'nama_customer' => $input['customer'],
            'telp' => $input['telp'],
            'alamat' => $input['alamat']
        );

        $insert_customer = $this->M_Customer->store($data_customer);
        $last_id_customer = $this->db->insert_id();

        $data_booking = array(
            'id_customer' => $last_id_customer,
            'id_jenis_layanan' => $input['jenis_layanan'],
            'code_transaksi' => 'TRANS-' . str_replace(' ', '', $input['nopol']) . '-' . time(),
            'jenis_kendaraan' => $input['jenis_kendaraan'],
            'merk_kendaraan' => $input['merk_kendaraan'],
            'tipe_kendaraan' => $input['tipe_kendaraan'],
            'nopol' => $input['nopol'],
            'tgl_service' => $input['tgl_service']
        );

        if (!$validate['success']) {
            $store_transaksi_booking = $this->M_Transaksi_Booking->store($data_booking);
            if ($store_transaksi_booking) {
                $last_transaksi_booking = $this->db->insert_id();
                $booking = $this->db->get_where('view_transaksi_booking', array('id' => $last_transaksi_booking));
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate, 'data' => $booking->row());
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate, 'data' => false);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate, 'data' => false);
        }

        if ($this->db->trans_status() === FALSE) {
            $this->db->trans_rollback();
        } else {
            $this->db->trans_commit();
        }

        echo json_encode($response);
    }
}
