<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ExceptionController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('auth');
        $this->auth->authenticate();
    }

    public function error_401()
    {
        return $this->load->view('errors/html/error_401');
    }
}
