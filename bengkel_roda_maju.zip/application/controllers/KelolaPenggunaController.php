<?php
defined('BASEPATH') or exit('No direct script access allowed');

class KelolaPenggunaController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library(['auth', 'form_validation']);
        $this->auth->authenticate();
        $this->auth->route_access();
        $this->load->model('M_Users');
        $this->load->model('M_Roles');
    }

    public function rules($id_users = null, $mode = false)
    {
        if (!is_null($id_users)) {
            $get_username = $this->db->get_where('users', array('id' => $id_users))->row();
            if ($this->input->post('username') != $get_username->username) {
                $is_unique =  '|is_unique[users.username]';
            } else {
                $is_unique =  '';
            }
        } else {
            $is_unique =  '|is_unique[users.username]';
        }


        $this->form_validation->set_rules(
            'name',
            'Nama Pengguna',
            'required',
            array(
                'required' => 'Nama Pengguna Tidak boleh kosong.',
            )
        );

        if ($mode) {
            if ($mode != '') {
                $this->form_validation->set_rules(
                    'username',
                    'Username',
                    'required' . $is_unique,
                    array(
                        'required' => 'Username Tidak boleh kosong.',
                        'is_unique' => '%s sudah tersedia, silakan gunakan username lain.'
                    )
                );
            }
        } else {
            $this->form_validation->set_rules(
                'username',
                'Username',
                'required' . $is_unique,
                array(
                    'required' => 'Username Tidak boleh kosong.',
                    'is_unique' => '%s sudah tersedia, silakan gunakan username lain.'
                )
            );
        }

        if (!$mode) {
            $this->form_validation->set_rules(
                'password',
                'Password',
                'required',
                array(
                    'required' => 'Password Tidak boleh kosong.',
                )
            );
        }

        $this->form_validation->set_rules(
            'roles',
            'Roles',
            'required',
            array(
                'required' => 'Roles Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'name' => form_error('name'),
                'username' => form_error('username'),
                'password' => form_error('password'),
                'roles' => form_error('roles'),
            );
        }

        return $array;
    }
    public function check_username($username)
    {
        $check = $this->db->get_where('users', array('username' => $username));
        if ($check->num_rows() == 0) {
            return TRUE;
        } else {
            $this->form_validation->set_message('check_username', 'Username sudah tersedia, silakan gunakan username lain.');
            return FALSE;
        }
    }

    public function index()
    {
        $get_roles = $this->M_Roles->AllRoles();
        $data = array(
            'role' => $get_roles->result()
        );
        admin_template('pages/KelolaPengguna/v_kelola_pengguna', $data, 'pages/KelolaPengguna/js_kelola_pengguna', 'Kelola Pengguna');
    }

    public function getData()
    {
        $users = $this->M_Users->AllUsers();
        echo json_encode($users->result());
    }

    public function show($id)
    {
        $get_users = $this->M_Users->show($id);
        echo json_encode($get_users->row());
    }

    public function store()
    {
        $input = $this->input->post();
        $validate = $this->rules();

        $data = array(
            'name' => $input['name'],
            'username' => $input['username'],
            'password' => password_hash($input['password'], PASSWORD_DEFAULT),
            'roles_id' => $input['roles'],
        );

        if (!$validate['success']) {
            $store_users = $this->M_Users->store($data);
            if ($store_users) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }

    public function update($id)
    {
        $input = $this->input->post();
        $validate = $this->rules($id, true);

        if ($input['password'] != '') {
            $data = array(
                'name' => $input['name'],
                'username' => $input['username'],
                'password' => password_hash($input['password'], PASSWORD_DEFAULT),
                'roles_id' => $input['roles']
            );
        } else {
            $data = array(
                'name' => $input['name'],
                'username' => $input['username'],
                'roles_id' => $input['roles']
            );
        }

        if (!$validate['success']) {
            $update_users = $this->M_Users->update($id, $data);
            if ($update_users) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }

    public function delete($id)
    {
        $delete = $this->M_Users->delete($id);
        if ($delete) {
            $response = array('message' => 'Berhasil menghapus data.');
        } else {
            $response = array('message' => 'Gagal menghapus data.');
        }

        echo json_encode($response);
    }
}
