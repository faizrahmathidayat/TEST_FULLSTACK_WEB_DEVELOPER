<?php
defined('BASEPATH') or exit('No direct script access allowed');

class DashboardController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['auth', 'form_validation']);
        $this->auth->authenticate();
        $this->auth->route_access();
        $this->load->model('M_Customer');
        $this->load->model('M_Transaksi_Booking');
    }

    public function index()
    {
        $total_customer = $this->M_Customer->AllCustomer();
        $total_transaksi_booking = $this->M_Transaksi_Booking->TransaksiBooking();
        $total_transaksi_batal = $this->M_Transaksi_Booking->TransaksiBooking(2); //transaksi dibatalkan
        $total_booking = $this->M_Transaksi_Booking->TransaksiBooking(0); //total booking
        $antrian_pengerjaan = $this->M_Transaksi_Booking->TransaksiBooking(4); //antrian pengerjaan
        $dalam_pengerjaan = $this->M_Transaksi_Booking->TransaksiBooking(3); //dalam pengerjaan
        $selesai_pengerjaan = $this->M_Transaksi_Booking->TransaksiBooking(1); //selesai pengerjaan

        $data = array(
            'total_customer' => $total_customer->num_rows(),
            'total_transaksi_booking' => $total_transaksi_booking->num_rows(),
            'total_transaksi_batal' => $total_transaksi_batal->num_rows(),
            'total_booking' => $total_booking->num_rows(),
            'antrian_pengerjaan' => $antrian_pengerjaan->num_rows(),
            'dalam_pengerjaan' => $dalam_pengerjaan->num_rows(),
            'selesai_pengerjaan' => $selesai_pengerjaan->num_rows(),
        );
        admin_template('pages/Dashboard/v_dashboard', $data, 'pages/Dashboard/js_dashboard', 'Dashboard');
    }
}
