<?php
defined('BASEPATH') or exit('No direct script access allowed');

class JenisLayananController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library(['auth', 'form_validation']);
        $this->auth->authenticate();
        $this->auth->route_access();
        $this->load->model('M_Jenis_Layanan');
        $this->load->model('M_Kategori_Layanan');
    }

    public function rules_store()
    {
        $this->form_validation->set_rules(
            'jenis_layanan',
            'Nama Kategori Layanan',
            'required',
            array(
                'required' => 'Jenis Layanan Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'jenis_layanan' => form_error('jenis_layanan'),
            );
        }

        return $array;
    }

    public function rules_update()
    {
        $this->form_validation->set_rules(
            'edit_jenis_layanan',
            'Jenis Layanan',
            'required',
            array(
                'required' => 'Jenis Layanan Tidak boleh kosong.',
            )
        );

        if ($this->form_validation->run()) {
            $array = array(
                'success' => false
            );
        } else {
            $array = array(
                'success'   => true,
                'jenis_layanan' => form_error('edit_jenis_layanan'),
            );
        }

        return $array;
    }

    public function index()
    {
        $data = array(
            'data' => $this->M_Kategori_Layanan->AllKategori()->result()
        );
        admin_template('pages/JenisLayanan/v_jenis_layanan', $data, 'pages/JenisLayanan/js_jenis_layanan', 'Jenis Layanan');
    }

    public function getData()
    {
        $jenis_layanan = $this->M_Jenis_Layanan->AllJenisLayanan();
        echo json_encode(array('data' => $jenis_layanan->result()));
    }

    public function store()
    {
        $input = $this->input->post();
        $validate = $this->rules_store();

        $data = array(
            'id_kategori_layanan' => $input['kategori_layanan'],
            'jenis_layanan' => $input['jenis_layanan'],
        );

        if (!$validate['success']) {
            $store_jenis_layanan = $this->M_Jenis_Layanan->store($data);
            if ($store_jenis_layanan) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }

        echo json_encode($response);
    }

    public function show($id)
    {
        $get_jenis_layanan = $this->db->get_where('jenis_layanan', array('id' => $id));

        echo json_encode($get_jenis_layanan->row());
    }

    public function update($id)
    {
        $input = $this->input->post();
        $validate = $this->rules_update();

        $data = array(
            'id_kategori_layanan' => $input['edit_kategori_layanan'],
            'jenis_layanan' => $input['edit_jenis_layanan']
        );

        if (!$validate['success']) {
            $update_jenis_layanan = $this->M_Jenis_Layanan->update($id, $data);
            if ($update_jenis_layanan) {
                $response = array('message' => 'Berhasil menyimpan data.', 'validate' => $validate);
            } else {
                $response = array('message' => 'Gagal menyimpan data.', 'validate' => $validate);
            }
        } else {
            $response = array('message' => 'Data tidak valid.', 'validate' => $validate);
        }
        echo json_encode($response);
    }
}
