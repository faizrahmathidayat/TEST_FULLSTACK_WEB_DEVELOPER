<?php
defined('BASEPATH') or exit('No direct script access allowed');

class AuthController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_Auth');
        $this->load->library(['auth', 'form_validation']);
    }

    public function index()
    {
        if (!$this->auth->loginStatus()) {
            $this->load->view('pages/Auth/v_login');
        } else {
            redirect('dashboard');
        }
    }

    public function login()
    {
        $input = $this->input->post();
        $this->auth->login($input);
    }

    public function logout()
    {
        if ($this->auth->logout())
            return redirect('/');

        return false;
    }
}
