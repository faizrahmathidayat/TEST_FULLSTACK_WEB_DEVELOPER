<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth
{
    protected $CI;

    public $user = null;
    public $userID = null;
    public $name = null;
    public $userName = null;
    public $password = null;
    public $Roles = null;
    public $loginStatus = false;
    public $error = array();

    public function __construct()
    {
        $this->CI = &get_instance();

        $this->init();
    }

    protected function init()
    {
        if ($this->CI->session->has_userdata("userID") && $this->CI->session->loginStatus) {
            $this->userID = $this->CI->session->userID;
            $this->Roles = $this->CI->session->Roles;
            $this->userName = $this->CI->session->userName;
            $this->name = $this->CI->session->name;
            $this->loginStatus = true;
        }

        return;
    }

    public function login($request)
    {
        if ($this->validate($request)) {
            $this->user = $this->credentials($this->userName, $this->password);
            if ($this->user) {
                return $this->setUser();
            } else {
                $this->CI->session->set_flashdata('error', 'Username or password invalid');
                redirect('/');
            }
        }
        $this->CI->session->set_flashdata('error', 'Username or password required');
        redirect('/');
    }

    protected function validate($request)
    {
        $this->CI->form_validation->set_rules('username', 'User Name', 'required');
        $this->CI->form_validation->set_rules('password', 'Password', 'required');

        if ($this->CI->form_validation->run() == TRUE) {
            $this->userName = $this->CI->input->post("username", TRUE);
            $this->password = $this->CI->input->post("password", TRUE);
            return true;
        }

        return false;
    }

    protected function credentials($username, $password)
    {
        $user = $this->CI->db->get_where("users", array("username" => $username))->row(0);
        if ($user && password_verify($password, $user->password)) {
            return $user;
        }

        return false;
    }

    protected function setUser()
    {
        $get_roles = $this->CI->db->get_where('roles', array('id' => $this->user->roles_id))->row();
        $this->userID = $this->user->id;
        $this->name = $this->user->name;
        $this->Roles = empty($get_roles) ? null : $get_roles->role_name;

        $this->CI->session->set_userdata(array(
            "userID" => $this->user->id,
            "userName" => $this->user->username,
            "name" => $this->user->name,
            "Roles" => empty($get_roles) ? null : $get_roles->role_name,
            "loginStatus" => true
        ));

        return redirect("dashboard");
    }

    public function loginStatus()
    {
        return $this->loginStatus;
    }

    public function authenticate()
    {
        if (!$this->loginStatus()) {
            return redirect('/');
        }

        return true;
    }

    public function logout()
    {
        $this->CI->session->unset_userdata(array("userID", "userName", "loginStatus"));
        $this->CI->session->sess_destroy();

        return true;
    }

    public function route_access()
    {
        if ($this->Roles != 'ADMIN')
            return redirect('exceptions/401');
    }
}
