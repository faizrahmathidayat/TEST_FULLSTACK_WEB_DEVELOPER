<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>401 Unauthorized</title>
    <style>
        * {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
        }

        body {
            text-align: center;
            margin: 0;
            background: linear-gradient(120deg, #6F1E51 0%, #ED4C67 100%);
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #fff;
        }

        img {
            width: 250px;
            margin: auto;
            padding-top: 3em;
        }

        h1 {
            font-weight: 200;
            font-size: 4em;
            margin: 1em;
        }

        p {
            font-size: 1.2em;
        }

        .button {
            background-color: #af4c4c;
            /* Green */
            border: none;
            color: white;
            padding: 15px 32px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            -webkit-transition-duration: 0.4s;
            /* Safari */
            transition-duration: 0.4s;
        }

        .button1 {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }
    </style>
</head>

<body>
    <div>
        <img src="https://images.plurk.com/5pHVCIyRNMdudWmVrrtQ.png" alt="">
        <h1>401 Unauthorized</h1>
        <a href="<?= base_url('logout') ?>" class="button button1">Logout</a>
    </div>

</body>

</html>