<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Booking Service</title>
    <link rel="stylesheet" href="<?= base_url('assets/templates/vendor/bootstrap/css/bootstrap.min.css') ?>">
</head>

<body>
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

    <div id="login-overlay" class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div id="detail_transaksi" hidden>
                    <h1>Detail Transaksi</h1>
                    <b>
                        <p>Code Transaksi : <span id="info_code_transaksi"></span></p>
                        <p>Tanggal Booking : <span id="info_tgl_booking"></span></p>
                        <p>Tanggal Service : <span id="info_tgl_service"></span></p>
                        <p>Layanan : <span id="info_jenis_layanan"></span></p>
                    </b>
                    <button onclick="window.print()">Simpan Bukti Booking</button>
                    <br>
                    <small>ini adalah code transaksi anda, tunjukan code transaksi kepada admin ketika melakukan service</small>
                </div>
            </div>

            <div id="content_booking">
                <div class="modal-header">
                    <h2 class="modal-title" id="myModalLabel">Bengkel Roda Maju</h2>
                    <p>Silakan tentukan tanggal service kendaraan anda.</p>
                </div>

                <div class="modal-body">
                    <span style="font-weight:bold;font-size:20px">Informasi Diri</span>
                    <form id="form_booking_service">
                        <!---form--->
                        <div class="form-group">
                            <!---input width--->
                            <div class="col-xs-6">
                                <label for="InputName">Nama Customer</label>
                                <div class="input-group customer">
                                    <input type="text" class="form-control" name="customer" id="customer" placeholder="Isi Nama Customer">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="customer_error" style="color:red;"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-6">
                                <label for="InputName">Telepon</label>
                                <div class="input-group telp">
                                    <input type="text" class="form-control" name="telp" id="telp" placeholder="Isi Telepon">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="telp_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <label>Alamat</label>
                                <div class="input-group alamat">
                                    <textarea class="form-control" name="alamat" id="alamat" cols="70"></textarea>
                                </div>
                                <span class="message_error" id="alamat_error" style="color:red;"></span>
                                <hr>
                            </div>
                        </div>

                        <span style="font-weight:bold;font-size:20px">Booking Service</span>
                        <!----------------------------break-------------------------------------------------------------> <br>
                        <!----------------------------break-------------------------------------------------------------> <br>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputEmail">Jenis Layanan</label>
                                <div class="input-group jenis_layanan">
                                    <select class="form-control" name="jenis_layanan" id="jenis_layanan">
                                        <?php foreach ($jenis_layanan as $data) : ?>
                                            <option value="<?= $data->id ?>"><?= $data->jenis_layanan ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="jenis_layanan_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputEmail">Jenis Kendaraan</label>
                                <div class="input-group jenis_kendaraan">
                                    <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Sepeda Motor / Mobil">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="jenis_kendaraan_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputEmail">Merk Kendaraan</label>
                                <div class="input-group merk_kendaraan">
                                    <input type="text" class="form-control" name="merk_kendaraan" id="merk_kendaraan" placeholder="Contoh : Honda">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="merk_kendaraan_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputEmail">Tipe Kendaraan</label>
                                <div class="input-group tipe_kendaraan">
                                    <input type="text" class="form-control" name="tipe_kendaraan" id="tipe_kendaraan" placeholder="Contoh : Supra 125">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="tipe_kendaraan_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputEmail">No. Polisi</label>
                                <div class="input-group nopol">
                                    <input type="text" class="form-control" name="nopol" id="nopol" placeholder="Contoh : B 2000 ABC">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span class="message_error" id="nopol_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <label for="InputProvince">Tanggal Service</label>
                                <div class="input-group tgl_service">
                                    <input type="date" class="form-control" name="tgl_service" id="tgl_service" value="<?= date('Y-m-d', strtotime(date('Y-m-d') . ' + 3 days')); ?>">
                                    <span class="input-group-addon"><span class="glyphicon glyphicon-asterisk"></span></span>
                                </div>
                                <span style="font-style:italic;color:green;font-size:10px;">Minimal 2 hari untuk menentukan tanggal service.</span>
                                <span class="message_error" id="tgl_service_error" style="color:red;"></span>
                                <!----------------------------break-------------------------------------------------------------> <br>
                            </div>
                        </div>
                    </form>
                    <div class="form-group">
                        <div class="input-group-addon">
                            <button class="btn btn-success pull-right" id="btn_booking_service">Booking</button>
                        </div>
                    </div>
                </div>
                <!---modal-body--->
            </div>

        </div>
    </div>

    <script src="<?= base_url('assets/plugins/sweet-alert/sweetalert.min.js') ?>"></script>
    <script src="<?= base_url('assets/templates/vendor/jquery/jquery.min.js') ?>"></script>
    <script src="<?= base_url('assets/templates/vendor/bootstrap/js/bootstrap.min.js') ?>"></script>
    <script>
        $(document).ready(function() {
            $('#detail_transaksi').prop('hidden', true);
            $('#content_booking').prop('hidden', false);
        });

        function SwalLoading(html = 'Loading ...', title = '') {
            return Swal.fire({
                title: title,
                html: html,
                timerProgressBar: true,
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading()
                }
            });
        }

        $('#btn_booking_service').on('click', function(e) {
            var data = $('#form_booking_service').serialize();
            $.ajax({
                url: 'booking/store',
                method: 'POST',
                dataType: 'JSON',
                data: data,
                beforeSend: function() {
                    $('.input-group').removeClass('has-error');
                    $('.message_error').text('');
                    SwalLoading();
                },
                success: function(response) {
                    Swal.close();
                    console.log(response)
                    if (response.validate.success) {
                        console.log(response.validate);
                        Swal.fire({
                            icon: 'warning',
                            title: 'Oops...',
                            text: response.message
                        });
                        $.each(response.validate, (key, val) => {
                            var has_error_form = $('.' + key);
                            console.log(has_error_form)
                            has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                            el = $('[id="' + key + '_error"]');
                            el.html(val);
                        });
                        return false;
                    }
                    Swal.fire({
                        icon: 'success',
                        title: 'Success',
                        text: 'Berhasil melakukan booking service'
                    });
                    $('#info_code_transaksi').text(response.data.code_transaksi);
                    $('#info_tgl_booking').text(response.data.tgl_booking);
                    $('#info_tgl_service').text(response.data.tgl_service);
                    $('#info_jenis_layanan').text(response.data.jenis_layanan);
                    $('#content_booking').prop('hidden', true);
                    $('#detail_transaksi').prop('hidden', false);
                },
                error: function(response) {
                    Swal.close();
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'INTERNAL_SERVER_ERROR'
                    });
                }
            });
        })
    </script>
</body>

</html>