</div>
<!-- Javascript -->
<script src="<?= base_url('assets/plugins/sweet-alert/sweetalert.min.js') ?>"></script>
<script src="<?= base_url('assets/templates/vendor/jquery/jquery.min.js') ?>"></script>
<script src="<?= base_url('assets/plugins/bs-custom-file-input/bs-custom-file-input.min.js') ?>"></script>
<script src="<?= base_url('assets/templates/vendor/bootstrap/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/templates/vendor/select2.full.min.js') ?>"></script>
<script src="<?= base_url('assets/templates/vendor/jquery-slimscroll/jquery.slimscroll.min.js') ?>"></script>
<script src="<?= base_url('assets/templates/scripts/klorofil-common.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/jquery.dataTables.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/datatables/dataTables.bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/plugins/toaster/toastr.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/accounting.min.js') ?>"></script>
<script>
    function SwalLoading(html = 'Loading ...', title = '') {
        return Swal.fire({
            title: title,
            html: html,
            timerProgressBar: true,
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading()
            }
        });
    }

    function ajax_call(url, method, data, callback) {
        $.ajax({
            url: url,
            method: method,
            dataType: 'JSON',
            data: data,
            beforeSend: function() {
                $('.form-group').removeClass('has-error');
                $('.help-block').text('');
                SwalLoading();
            },
            error: function(response) {
                Swal.close();
                switch (true) {
                    case typeof response.responseText !== 'undefined':
                        console.log(response.responseText);
                        break;
                    case response.statusText !== 'abort' && e.status === 0:
                        alert('Please check your internet connection');
                        break;
                    case response.statusText === 'abort':
                        break;
                    default:
                        console.error(response);
                }
            },
            complete: function(response) {
                Swal.close();
                callback(response);
            }
        });
    }

    function clear_form_has_error(modal_id, form_id) {
        $('#' + modal_id).on('hidden.bs.modal', function(e) {
            $('.form-group').removeClass('has-error');
            $('.help-block').text('');
            $('#' + form_id)[0].reset();
        });
    }
</script>
<?php $js != null ? $this->load->view($js) : '';  ?>