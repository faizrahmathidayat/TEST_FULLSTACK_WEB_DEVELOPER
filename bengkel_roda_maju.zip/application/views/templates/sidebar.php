<!-- LEFT SIDEBAR -->
<div id="sidebar-nav" class="sidebar">
    <div class="sidebar-scroll">
        <nav>
            <ul class="nav">
                <li><a href="<?= base_url('dashboard') ?>" class="<?= $this->uri->segment(1) == 'dashboard' ? 'active' : '' ?>"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>

                <li><a href="<?= base_url('customer') ?>" class="<?= $this->uri->segment(1) == 'customer' ? 'active' : '' ?>"><i class="lnr lnr-users"></i> <span>Customer</span></a></li>

                <li><a href="<?= base_url('kategori-layanan') ?>" class="<?= $this->uri->segment(1) == 'kategori-layanan' ? 'active' : '' ?>"><i class="lnr lnr-chart-bars"></i> <span>Kategori Layanan</span></a></li>

                <li><a href="<?= base_url('jenis-layanan') ?>" class="<?= $this->uri->segment(1) == 'jenis-layanan' ? 'active' : '' ?>"><i class="lnr lnr-chart-bars"></i> <span>Jenis Layanan</span></a></li>

                <li><a href="<?= base_url('transaksi-booking') ?>" class="<?= $this->uri->segment(1) == 'transaksi-booking' ? 'active' : '' ?>"><i class="lnr lnr-chart-bars"></i> <span>Transaksi Booking</span></a></li>

                <li>
                    <a href="#subPages" data-toggle="collapse" class="collapsed"><i class="lnr lnr-cog"></i> <span>Pengaturan</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
                    <div id="subPages" class="collapse ">
                        <ul class="nav">
                            <li><a href="<?= base_url('kelola-pengguna') ?>" class="<?= $this->uri->segment(1) == 'kelola-pengguna' ? 'active' : '' ?>">Kelola Pengguna</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </nav>
    </div>
</div>
<!-- END LEFT SIDEBAR -->