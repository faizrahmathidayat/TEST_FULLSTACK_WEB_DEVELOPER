<script>
    $(document).ready(function() {
        clear_form_has_error('modal_jenis_layanan', 'form_jenis_layanan');
        mapping_data_jenis_layanan();

        $('#btn_simpan_jenis_layanan').on('click', function(e) {
            e.preventDefault();
            ajax_call('jenis-layanan/store', 'POST', $("#form_jenis_layanan").serialize(), function(response) {
                var res = response.responseJSON;

                if (res.validate.success) {
                    toastr["warning"](res.message);
                    $.each(res.validate, (key, val) => {
                        var has_error_form = $('#' + 'has_error_' + key);
                        has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                        el = $('[id="' + key + '_error"]');
                        el.html(val);
                    });
                    return false;
                }
                mapping_data_jenis_layanan();
                toastr["success"](res.message);
            });
        });
    });

    function mapping_data_jenis_layanan() {
        ajax_call('jenis-layanan/get-data', 'GET', '', function(response) {
            var res = response.responseJSON;
            var html = '';
            var no = 1;
            $.each(res.data, function(key, val) {
                html += `<tr>`;
                html += `<td>` + no++ + `</td>`;
                html += `<td>` + val.nama_kategori + `</td>`;
                html += `<td>` + val.jenis_layanan + `</td>`;
                html += `<td><button class="btn btn-xs btn-primary" type="button" onclick="show_edit_jenis_layanan(` + val.id + `)">Ubah</button></td>`;
                html += `</tr>`;
            });
            $('#data_jenis_layanan').html(html);
            $('#tbl_jenis_layanan').DataTable();
        });
    }

    function show_edit_jenis_layanan(id) {
        if (id) {
            ajax_call('jenis-layanan/show/' + id, 'GET', '', function(response) {
                var res = response.responseJSON;
                $('#id_jenis_layanan').val(res.id);
                $('#edit_kategori_layanan').val(res.id_kategori_layanan);
                $('#edit_jenis_layanan').val(res.jenis_layanan);
                $('#modal_edit_jenis_layanan').modal('show');
            });
        } else {
            toastr['error']("ID Jenis Layanan tidak ditemukan.");
        }
    }

    $('#btn_ubah_jenis_layanan').on('click', function(e) {
        e.preventDefault();
        var id_jenis_layanan = $('#id_jenis_layanan').val();

        ajax_call('jenis-layanan/update/' + id_jenis_layanan, 'POST', $("#form_edit_jenis_layanan").serialize(), function(response) {
            var res = response.responseJSON;

            if (res.validate.success) {
                toastr["warning"](res.message);
                $.each(res.validate, (key, val) => {
                    var has_error = key.replace('_error', '');
                    var has_error_form = $('#' + 'has_error_edit_' + has_error);
                    has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                    el = $('[id="edit_' + key + '_error"]');
                    el.html(val);
                });
                return false;
            }
            mapping_data_jenis_layanan();
            toastr["success"](res.message);
        });
    })
</script>