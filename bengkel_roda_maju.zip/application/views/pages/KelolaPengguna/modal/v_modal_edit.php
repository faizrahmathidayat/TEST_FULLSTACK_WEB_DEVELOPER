<!-- Modal -->
<div class="modal fade" id="modal_ubah_kelola_pengguna" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Ubah Pengguna</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_ubah_kelola_pengguna">
                    <input type="hidden" name="id_users" id="id_users">
                    <div class="form-group" id="has_error_ubah_name">
                        <label class="control-label" for="inputError">Nama</label>
                        <input type="text" class="form-control" name="name" id="ubah_name" placeholder="Nama Pengguna">
                        <span class="help-block" id="ubah_name_error"></span>
                    </div>
                    <div class="form-group" id="has_error_ubah_username">
                        <label class="control-label" for="inputError">Username</label>
                        <input type="text" class="form-control" name="username" id="ubah_username" placeholder="Nama Pengguna">
                        <span class="help-block" id="ubah_username_error"></span>
                    </div>
                    <div class="form-group" id="has_error_ubah_password">
                        <label class="control-label" for="inputError">Password</label>
                        <input type="text" class="form-control" name="password" id="ubah_password" placeholder="ubah_Password">
                        <small style="color:yellow;">Kosongkan jika password tidak diubah.</small>
                        <span class="help-block" id="ubah_password_error"></span>
                    </div>
                    <div class="form-group" id="has_error_ubah_roles">
                        <label class="control-label" for="inputError">Roles</label>
                        <select class="form-control" name="roles" id="ubah_roles">
                            <?php foreach ($role as $roles) : ?>
                                <option value="<?= $roles->id ?>"><?= $roles->role_name ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="help-block" id="ubah_roles_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn_ubah_kelola_pengguna" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>