<!-- Modal -->
<div class="modal fade" id="modal_tambah_kelola_pengguna" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Tambah Pengguna</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_tambah_kelola_pengguna">
                    <div class="form-group" id="has_error_name">
                        <label class="control-label" for="inputError">Nama</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Nama Pengguna">
                        <span class="help-block" id="name_error"></span>
                    </div>
                    <div class="form-group" id="has_error_username">
                        <label class="control-label" for="inputError">Username</label>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Username">
                        <span class="help-block" id="username_error"></span>
                    </div>
                    <div class="form-group" id="has_error_password">
                        <label class="control-label" for="inputError">Password</label>
                        <input type="text" class="form-control" name="password" id="password" placeholder="Password">
                        <span class="help-block" id="password_error"></span>
                    </div>
                    <div class="form-group" id="has_error_roles">
                        <label class="control-label" for="inputError">Roles</label>
                        <select class="form-control" name="roles" id="roles">
                            <?php foreach ($role as $roles) : ?>
                                <option value="<?= $roles->id ?>"><?= $roles->role_name ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="help-block" id="roles_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn_simpan_kelola_pengguna" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>