<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <div class="panel panel-headline">
                <div class="panel-heading">
                    <h3 class="panel-title">Kelola Pengguna</h3>
                </div>
                <div class="panel-body">
                    <div style="margin-bottom: 10px;">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal_tambah_kelola_pengguna">Tambah</button>
                    </div>
                    <table id="tbl_kelola_pengguna" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Username</th>
                                <th>Roles</th>
                                <th>Created at</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="data_kelola_pengguna">
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END OVERVIEW -->
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->
<?php $this->load->view('pages/KelolaPengguna/modal/v_modal_add'); ?>
<?php $this->load->view('pages/KelolaPengguna/modal/v_modal_edit'); ?>