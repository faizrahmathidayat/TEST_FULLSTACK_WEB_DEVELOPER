<script>
    $(document).ready(function() {
        clear_form_has_error('modal_tambah_kelola_pengguna', 'form_tambah_kelola_pengguna');
        mapping_data_kelola_pengguna();

        $('#btn_simpan_kelola_pengguna').on('click', function(e) {
            e.preventDefault();
            ajax_call('kelola-pengguna/store', 'POST', $("#form_tambah_kelola_pengguna").serialize(), function(response) {
                var res = response.responseJSON;

                if (res.validate.success) {
                    toastr["warning"](res.message);
                    $.each(res.validate, (key, val) => {
                        var has_error_form = $('#' + 'has_error_' + key);
                        has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                        el = $('[id="' + key + '_error"]');
                        el.html(val);
                    });
                    return false;
                }
                mapping_data_kelola_pengguna();
                toastr["success"](res.message);
            });
        });
    });

    var session_id_users = '<?= $this->auth->userID ?>';

    function mapping_data_kelola_pengguna() {
        ajax_call('kelola-pengguna/get-data', 'GET', '', function(response) {
            var res = response.responseJSON;
            var html = '';
            var no = 1;
            $.each(res, function(key, val) {
                var disableBtnHapus = '';
                if (val.id == session_id_users) {
                    disableBtnHapus = 'disabled';
                }
                html += `<tr>`;
                html += `<td>` + no++ + `</td>`;
                html += `<td>` + val.name + `</td>`;
                html += `<td>` + val.username + `</td>`;
                html += `<td>` + val.role_name + `</td>`;
                html += `<td>` + val.created_at + `</td>`;
                html += `<td><button class="btn btn-xs btn-primary" type="button" onclick="show_edit_kelola_pengguna(` + val.id + `)">Ubah</button> <button class="btn btn-xs btn-danger" type="button" ` + disableBtnHapus + ` onclick="btn_delete_kelola_pengguna(` + val.id + `)">Hapus</button></td>`;
                html += `</tr>`;
                html += `</tr>`;
            });
            $('#data_kelola_pengguna').html(html);
            $('#tbl_kelola_pengguna').DataTable();
        });
    }

    function show_edit_kelola_pengguna(id) {
        if (id) {
            ajax_call('kelola-pengguna/show/' + id, 'GET', '', function(response) {
                var res = response.responseJSON;
                $('#id_users').val(res.id);
                $('#ubah_name').val(res.name);
                $('#ubah_username').val(res.username);
                $('#ubah_roles').val(res.roles_id);
                $('#modal_ubah_kelola_pengguna').modal('show');
            });
        } else {
            toastr['error']("ID Users tidak ditemukan.");
        }
    }

    $('#btn_ubah_kelola_pengguna').on('click', function(e) {
        e.preventDefault();
        var id_users = $('#id_users').val();

        ajax_call('kelola-pengguna/update/' + id_users, 'POST', $("#form_ubah_kelola_pengguna").serialize(), function(response) {
            var res = response.responseJSON;

            if (res.validate.success) {
                toastr["warning"](res.message);
                $.each(res.validate, (key, val) => {
                    var has_error = key.replace('_error', '');
                    var has_error_form = $('#' + 'has_error_ubah_' + has_error);
                    has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                    el = $('[id="ubah_' + key + '_error"]');
                    el.html(val);
                });
                return false;
            }
            mapping_data_kelola_pengguna();
            toastr["success"](res.message);
        });
    })

    function btn_delete_kelola_pengguna(id) {
        if (id) {
            Swal.fire({
                title: 'Apa kamu yakin?',
                text: "Data yang sudah dihapus tidak dapat dikembalikan.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Hapus!'
            }).then((result) => {
                if (result.isConfirmed) {
                    ajax_call('kelola-pengguna/delete/' + id, 'GET', '', function(response) {
                        var res = response.responseJSON;
                        mapping_data_kelola_pengguna();
                        toastr["success"](res.message);
                    });
                }
            })
        } else {
            toastr['error']("ID Users tidak ditemukan.");
        }
    }
</script>