<script>
    $(document).ready(function() {
        clear_form_has_error('modal_kategori_layanan', 'form_kategori_layanan');
        mapping_data_kategori_layanan();

        $('#btn_simpan_kategori_layanan').on('click', function(e) {
            e.preventDefault();
            ajax_call('kategori-layanan/store', 'POST', $("#form_kategori_layanan").serialize(), function(response) {
                var res = response.responseJSON;

                if (res.validate.success) {
                    toastr["warning"](res.message);
                    $.each(res.validate, (key, val) => {
                        var has_error_form = $('#' + 'has_error_' + key);
                        has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                        el = $('[id="' + key + '_error"]');
                        el.html(val);
                    });
                    return false;
                }
                mapping_data_kategori_layanan();
                toastr["success"](res.message);
            });
        });
    });

    function mapping_data_kategori_layanan() {
        ajax_call('kategori-layanan/get-data', 'GET', '', function(response) {
            var res = response.responseJSON;
            var html = '';
            var no = 1;
            $.each(res.data, function(key, val) {
                html += `<tr>`;
                html += `<td>` + no++ + `</td>`;
                html += `<td>` + val.nama_kategori + `</td>`;
                html += `<td><button class="btn btn-xs btn-primary" type="button" onclick="show_edit_kategori_layanan(` + val.id + `)">Ubah</button></td>`;
                html += `</tr>`;
                html += `</tr>`;
            });
            $('#data_kategori_layanan').html(html);
            $('#tbl_kategori_layanan').DataTable();
        });
    }

    function show_edit_kategori_layanan(id) {
        if (id) {
            ajax_call('kategori-layanan/show/' + id, 'GET', '', function(response) {
                var res = response.responseJSON;
                $('#id_kategori_layanan').val(res.id);
                $('#edit_nama_kategori').val(res.nama_kategori);
                $('#modal_edit_kategori_layanan').modal('show');
            });
        } else {
            toastr['error']("ID Kategori Layanan tidak ditemukan.");
        }
    }

    $('#btn_ubah_kategori_layanan').on('click', function(e) {
        e.preventDefault();
        var id_kategori_layanan = $('#id_kategori_layanan').val();

        ajax_call('kategori-layanan/update/' + id_kategori_layanan, 'POST', $("#form_edit_kategori_layanan").serialize(), function(response) {
            var res = response.responseJSON;

            if (res.validate.success) {
                toastr["warning"](res.message);
                $.each(res.validate, (key, val) => {
                    var has_error = key.replace('_error', '');
                    var has_error_form = $('#' + 'has_error_edit_' + has_error);
                    has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                    el = $('[id="edit_' + key + '_error"]');
                    el.html(val);
                });
                return false;
            }
            mapping_data_kategori_layanan();
            toastr["success"](res.message);
        });
    })
</script>