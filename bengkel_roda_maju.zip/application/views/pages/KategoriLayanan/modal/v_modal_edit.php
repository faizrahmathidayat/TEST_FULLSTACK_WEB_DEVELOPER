<!-- Modal -->
<div class="modal fade" id="modal_edit_kategori_layanan" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Ubah Kategori Layanan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_edit_kategori_layanan">
                    <input type="hidden" id="id_kategori_layanan">
                    <div class="form-group" id="has_error_edit_nama_kategori">
                        <label class="control-label" for="inputError">Nama Kategori Layanan</label>
                        <input type="text" class="form-control" name="edit_nama_kategori" id="edit_nama_kategori" placeholder="Nama Kategori Layanan">
                        <span class="help-block" id="edit_nama_kategori_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn_ubah_kategori_layanan" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>