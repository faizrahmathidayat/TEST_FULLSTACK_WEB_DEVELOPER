<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <div class="panel panel-headline">
                <div class="panel-heading">
                    <h3 class="panel-title">Kategori Layanan</h3>
                </div>
                <div class="panel-body">
                    <div style="margin-bottom: 10px;">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal_kategori_layanan">Tambah</button>
                    </div>
                    <table id="tbl_kategori_layanan" class="table table-striped" style="width:100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kategori Layanan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="data_kategori_layanan">
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- END OVERVIEW -->
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->
<?php $this->load->view('pages/KategoriLayanan/modal/v_modal_add'); ?>
<?php $this->load->view('pages/KategoriLayanan/modal/v_modal_edit'); ?>