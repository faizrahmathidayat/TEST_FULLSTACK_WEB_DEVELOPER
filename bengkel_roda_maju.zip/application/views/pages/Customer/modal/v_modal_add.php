<!-- Modal -->
<div class="modal fade" id="form_add_customer" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Tambah Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_customer">
                    <div class="form-group" id="has_error_nama_customer">
                        <label class="control-label" for="inputError">Nama Customer</label>
                        <input type="text" class="form-control" name="nama_customer" id="nama_customer" placeholder="Nama Customer">
                        <span class="help-block" id="nama_customer_error"></span>
                    </div>
                    <div class="form-group" id="has_error_telp">
                        <label class="control-label" for="inputError">Telepon</label>
                        <input type="text" class="form-control" name="telp" id="telp" placeholder="Telepon">
                        <span class="help-block" id="telp_error"></span>
                    </div>
                    <div class="form-group" id="has_error_alamat">
                        <label class="control-label" for="inputError">Alamat</label>
                        <textarea class="form-control" name="alamat" id="alamat"></textarea>
                        <span class="help-block" id="alamat_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn_simpan_customer" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>