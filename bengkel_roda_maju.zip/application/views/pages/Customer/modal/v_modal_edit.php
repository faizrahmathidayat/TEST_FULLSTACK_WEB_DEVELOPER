<!-- Modal -->
<div class="modal fade" id="modal_edit_customer" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Ubah Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_edit_customer">
                    <input type="hidden" id="id_customer">
                    <div class="form-group" id="has_error_edit_nama_customer">
                        <label class="control-label" for="inputError">Nama Customer</label>
                        <input type="text" class="form-control" name="edit_nama_customer" id="edit_nama_customer" placeholder="Nama Customer">
                        <span class="help-block" id="edit_nama_customer_error"></span>
                    </div>
                    <div class="form-group" id="has_error_edit_telp">
                        <label class="control-label" for="inputError">Telepon</label>
                        <input type="text" class="form-control" name="edit_telp" id="edit_telp" placeholder="Telepon">
                        <span class="help-block" id="edit_telp_error"></span>
                    </div>
                    <div class="form-group" id="has_error_edit_alamat">
                        <label class="control-label" for="inputError">Alamat</label>
                        <textarea class="form-control" name="edit_alamat" id="edit_alamat"></textarea>
                        <span class="help-block" id="edit_alamat_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" id="btn_ubah_customer" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>