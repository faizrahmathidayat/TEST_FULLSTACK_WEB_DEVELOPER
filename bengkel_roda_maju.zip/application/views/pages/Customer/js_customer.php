<script>
    $(document).ready(function() {
        clear_form_has_error('form_add_customer');
        mapping_data_customer();

        $('#btn_simpan_customer').on('click', function(e) {
            e.preventDefault();
            ajax_call('customer/store', 'POST', $("#form_customer").serialize(), function(response) {
                var res = response.responseJSON;

                if (res.validate.success) {
                    toastr["warning"](res.message);
                    $.each(res.validate, (key, val) => {
                        var has_error = key.replace('_error', '');
                        var has_error_form = $('#' + 'has_error_' + has_error);
                        has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                        el = $('[id="' + key + '_error"]');
                        el.html(val);
                    });
                    return false;
                }
                mapping_data_customer();
                toastr["success"](res.message);
            });
        });
    });

    function mapping_data_customer() {
        ajax_call('customer/get-data', 'GET', '', function(response) {
            var res = response.responseJSON;
            var html = '';
            var no = 1;
            $.each(res.data, function(key, val) {
                html += `<tr>`;
                html += `<td>` + no++ + `</td>`;
                html += `<td>` + val.nama_customer + `</td>`;
                html += `<td>` + val.telp + `</td>`;
                html += `<td>` + val.alamat + `</td>`;
                html += `<td><button class="btn btn-xs btn-primary" type="button" onclick="show_edit_customer(` + val.id + `)">Ubah</button></td>`;
                html += `</tr>`;
            });
            $('#data_customer').html(html);
            $('#tbl_customer').DataTable();
        });
    }

    function show_edit_customer(id) {
        if (id) {
            ajax_call('customer/show/' + id, 'GET', '', function(response) {
                var res = response.responseJSON;
                $('#id_customer').val(res.id);
                $('#edit_nama_customer').val(res.nama_customer);
                $('#edit_telp').val(res.telp);
                $('#edit_alamat').val(res.alamat);
                $('#modal_edit_customer').modal('show');
            });
        } else {
            toastr['error']("ID customer tidak ditemukan.");
        }
    }

    $('#btn_ubah_customer').on('click', function(e) {
        e.preventDefault();
        var id_customer = $('#id_customer').val();

        ajax_call('customer/update/' + id_customer, 'POST', $("#form_edit_customer").serialize(), function(response) {
            var res = response.responseJSON;

            if (res.validate.success) {
                toastr["warning"](res.message);
                $.each(res.validate, (key, val) => {
                    var has_error = key.replace('_error', '');
                    var has_error_form = $('#' + 'has_error_edit_' + has_error);
                    has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                    el = $('[id="edit_' + key + '_error"]');
                    el.html(val);
                });
                return false;
            }
            mapping_data_customer();
            toastr["success"](res.message);
        });
    })
</script>