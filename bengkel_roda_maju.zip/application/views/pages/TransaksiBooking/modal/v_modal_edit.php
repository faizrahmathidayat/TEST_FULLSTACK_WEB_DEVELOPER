<!-- Modal -->
<div class="modal fade" id="modal_edit_transaksi_booking" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Ubah Transaksi Booking</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="height:350px;overflow:auto;">
                <form id="form_edit_transaksi_booking">
                    <input type="hidden" id="id_transaksi_booking">
                    <div class="has_readonly">
                        <div class="form-group" id="has_error_edit_customer">
                            <label class="control-label" for="inputError">Customer</label>
                            <select class="form-control" name="edit_customer" id="edit_customer">
                                <option value="">Pilih Customer</option>
                                <?php foreach ($customer as $customers) : ?>
                                    <option value="<?= $customers->id ?>"><?= $customers->nama_customer ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="help-block" id="edit_customer_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_jenis_layanan">
                            <label class="control-label" for="inputError">Jenis Layanan</label>
                            <select class="form-control" name="edit_jenis_layanan" id="edit_jenis_layanan">
                                <option value="">Pilih Jenis Layanan</option>
                                <?php foreach ($jenis_layanan as $jenis_layanans) : ?>
                                    <option value="<?= $jenis_layanans->id ?>"><?= $jenis_layanans->jenis_layanan ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="help-block" id="edit_jenis_layanan_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_jenis_kendaraan">
                            <label class="control-label" for="inputError">Jenis Kendaraan</label>
                            <input type="text" class="form-control" name="edit_jenis_kendaraan" id="edit_jenis_kendaraan" placeholder="Jenis Kendaraan">
                            <span class="help-block" id="edit_jenis_kendaraan_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_merk_kendaraan">
                            <label class="control-label" for="inputError">Merk Kendaraan</label>
                            <input type="text" class="form-control" name="edit_merk_kendaraan" id="edit_merk_kendaraan" placeholder="Merk Kendaraan">
                            <span class="help-block" id="edit_merk_kendaraan_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_tipe_kendaraan">
                            <label class="control-label" for="inputError">Tipe Kendaraan</label>
                            <input type="text" class="form-control" name="edit_tipe_kendaraan" id="edit_tipe_kendaraan" placeholder="Tipe Kendaraan">
                            <span class="help-block" id="edit_tipe_kendaraan_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_nopol">
                            <label class="control-label" for="inputError">No. Polisi</label>
                            <input type="text" class="form-control" name="edit_nopol" id="edit_nopol" placeholder="No. Polisi">
                            <span class="help-block" id="edit_nopol_error"></span>
                        </div>
                        <div class="form-group" id="has_error_edit_tgl_service">
                            <label class="control-label" for="inputError">Tanggal Service</label>
                            <input type="date" class="form-control" name="edit_tgl_service" id="edit_tgl_service">
                            <span class="help-block" id="edit_tgl_service_error"></span>
                        </div>
                    </div>
                    <div class="form-group" id="has_error_edit_status">
                        <label class="control-label" for="inputError">Status</label>
                        <select class="form-control" name="edit_status" id="edit_status">
                            <option value="0">Booking</option>
                            <option value="4">Dalam Antrian</option>
                            <option value="3">Dalam Pengerjaan</option>
                            <option value="2">Batalkan</option>
                            <option value="1">Selesai</option>
                        </select>
                        <span class="help-block" id="edit_status_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="button" id="btn_edit_transaksi_booking" class="btn btn-primary">Simpan</button>
            </div>
        </div>
    </div>
</div>