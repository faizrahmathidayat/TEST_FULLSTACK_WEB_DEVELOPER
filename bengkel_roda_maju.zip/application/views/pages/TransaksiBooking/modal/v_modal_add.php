<!-- Modal -->
<div class="modal fade" id="modal_tambah_transaksi_booking" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Tambah Transaksi Booking</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="height:350px;overflow:auto;">
                <form id="form_tambah_transaksi_booking">
                    <div class="form-group" id="has_error_customer">
                        <label class="control-label" for="inputError">Customer</label>
                        <select class="form-control" name="customer" id="customer">
                            <option value="">Pilih Customer</option>
                            <?php foreach ($customer as $customers) : ?>
                                <option value="<?= $customers->id ?>"><?= $customers->nama_customer ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="help-block" id="customer_error"></span>
                    </div>
                    <div class="form-group" id="has_error_jenis_layanan">
                        <label class="control-label" for="inputError">Jenis Layanan</label>
                        <select class="form-control" name="jenis_layanan" id="jenis_layanan">
                            <option value="">Pilih Jenis Layanan</option>
                            <?php foreach ($jenis_layanan as $jenis_layanans) : ?>
                                <option value="<?= $jenis_layanans->id ?>"><?= $jenis_layanans->jenis_layanan ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span class="help-block" id="jenis_layanan_error"></span>
                    </div>
                    <div class="form-group" id="has_error_jenis_kendaraan">
                        <label class="control-label" for="inputError">Jenis Kendaraan</label>
                        <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan">
                        <span class="help-block" id="jenis_kendaraan_error"></span>
                    </div>
                    <div class="form-group" id="has_error_merk_kendaraan">
                        <label class="control-label" for="inputError">Merk Kendaraan</label>
                        <input type="text" class="form-control" name="merk_kendaraan" id="merk_kendaraan" placeholder="Merk Kendaraan">
                        <span class="help-block" id="merk_kendaraan_error"></span>
                    </div>
                    <div class="form-group" id="has_error_tipe_kendaraan">
                        <label class="control-label" for="inputError">Tipe Kendaraan</label>
                        <input type="text" class="form-control" name="tipe_kendaraan" id="tipe_kendaraan" placeholder="Tipe Kendaraan">
                        <span class="help-block" id="tipe_kendaraan_error"></span>
                    </div>
                    <div class="form-group" id="has_error_nopol">
                        <label class="control-label" for="inputError">No. Polisi</label>
                        <input type="text" class="form-control" name="nopol" id="nopol" placeholder="No. Polisi">
                        <span class="help-block" id="nopol_error"></span>
                    </div>
                    <div class="form-group" id="has_error_tgl_service">
                        <label class="control-label" for="inputError">Tanggal Service</label>
                        <input type="date" class="form-control" name="tgl_service" id="tgl_service" value="<?= date('Y-m-d', strtotime(date('Y-m-d') . ' + 3 days')); ?>">
                        <span style="font-style:italic;color:green;font-size:10px;">Minimal 2 hari untuk menentukan tanggal service.</span>
                        <span class="help-block" id="tgl_service_error"></span>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="button" id="btn_simpan_transaksi_booking" class="btn btn-primary">Simpan</button>
            </div>
        </div>
    </div>
</div>