<script>
    $(document).ready(function() {
        clear_form_has_error('modal_tambah_transaksi_booking', 'form_tambah_transaksi_booking');
        clear_form_has_error('modal_edit_transaksi_booking', 'form_edit_transaksi_booking');
        mapping_data_transaksi_booking();

        $('#btn_simpan_transaksi_booking').on('click', function(e) {
            e.preventDefault();
            ajax_call('transaksi-booking/store', 'POST', $("#form_tambah_transaksi_booking").serialize(), function(response) {
                var res = response.responseJSON;

                if (res.validate.success) {
                    toastr["warning"](res.message);
                    $.each(res.validate, (key, val) => {
                        var has_error_form = $('#' + 'has_error_' + key);
                        has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                        el = $('[id="' + key + '_error"]');
                        el.html(val);
                    });
                    return false;
                }
                mapping_data_transaksi_booking();
                toastr["success"](res.message);
            });
        });
    });

    function mapping_data_transaksi_booking() {
        ajax_call('transaksi-booking/get-data', 'GET', '', function(response) {
            var res = response.responseJSON;
            console.log(res);
            var html = '';
            var no = 1;
            $.each(res.data, function(key, val) {
                var status_pengerjaan = '';

                switch (parseInt(val.status_pengerjaan)) {
                    case 0:
                        status_pengerjaan = '<span class="label label-primary">Booking</span>';
                        break;
                    case 1:
                        status_pengerjaan = '<span class="label label-success">Selesai</span>';
                        break;
                    case 2:
                        status_pengerjaan = '<span class="label label-warning">Batal</span>';
                        break;
                    case 3:
                        status_pengerjaan = '<span class="label label-info">Dalam Pengerjaan</span>';
                        break;
                    case 4:
                        status_pengerjaan = '<span class="label label-default">Dalam Antrian</span>';
                        break;
                    case 5:
                        status_pengerjaan = '<span class="label label-danger">DIHAPUS</span>';
                        break;
                    default:
                        status_pengerjaan = '<span class="label label-default">Status Pengerjaan tidak ditemukan</span>';
                        break;
                }

                var btnUbahDisabled = '';
                var btnHapusDisabled = '';

                if (val.status_pengerjaan == 1 || val.status_pengerjaan == 2 || val.status_pengerjaan == 5) {
                    btnUbahDisabled = 'disabled';
                    btnHapusDisabled = 'disabled';
                }

                if (val.status_pengerjaan == 3) {
                    btnHapusDisabled = 'disabled';
                }

                html += `<tr>`;
                html += `<td>` + no++ + `</td>`;
                html += `<td>` + val.code_transaksi + `</td>`;
                html += `<td>` + val.nama_customer + `</td>`;
                html += `<td>` + val.jenis_layanan + `</td>`;
                html += `<td>` + val.jenis_kendaraan + `</td>`;
                html += `<td>` + val.merk_kendaraan + `</td>`;
                html += `<td>` + val.tipe_kendaraan + `</td>`;
                html += `<td>` + val.nopol + `</td>`;
                html += `<td>` + val.tgl_booking + `</td>`;
                html += `<td>` + val.tgl_service + `</td>`;
                html += `<td>` + status_pengerjaan + `</td>`;
                html += `<td>` + val.created_by + `</td>`;
                html += `<td>` + val.updated_by + `</td>`;
                html += `<td><button class="btn btn-xs btn-primary" ` + btnUbahDisabled + ` type="button" onclick="show_edit_transaksi_booking(` + val.id + `)">Ubah</button> <button class="btn btn-xs btn-danger" ` + btnHapusDisabled + ` type="button" onclick="btn_hapus_transaksi_booking(` + val.id + `)">Hapus</button></td>`;
                html += `</tr>`;
            });
            $('#data_transaksi_booking').html(html);
            $('#tbl_transaksi_booking').DataTable();
        });
    }

    function show_edit_transaksi_booking(id) {
        if (id) {
            ajax_call('transaksi-booking/show/' + id, 'GET', '', function(response) {
                var res = response.responseJSON;
                $('#id_transaksi_booking').val(id);
                $('#edit_customer').val(res.id_customer);
                $('#edit_jenis_layanan').val(res.id_jenis_layanan);
                $('#edit_jenis_kendaraan').val(res.jenis_kendaraan);
                $('#edit_merk_kendaraan').val(res.merk_kendaraan);
                $('#edit_tipe_kendaraan').val(res.tipe_kendaraan);
                $('#edit_nopol').val(res.nopol);
                $('#edit_tgl_service').val(res.tgl_service);
                $('#edit_status').val(res.status_pengerjaan);

                if (res.status_pengerjaan == 3) {
                    $('.has_readonly').prop('hidden', true);
                } else {
                    $('.has_readonly').prop('hidden', false);
                }

                $('#modal_edit_transaksi_booking').modal('show');
            });
        } else {
            toastr['error']("ID Transaksi Booking tidak ditemukan.");
        }
    }

    $('#btn_edit_transaksi_booking').on('click', function(e) {
        e.preventDefault();
        var id_transaksi_booking = $('#id_transaksi_booking').val();

        ajax_call('transaksi-booking/update/' + id_transaksi_booking, 'POST', $("#form_edit_transaksi_booking").serialize(), function(response) {
            var res = response.responseJSON;

            if (res.validate.success) {
                toastr["warning"](res.message);
                $.each(res.validate, (key, val) => {
                    var has_error = key.replace('_error', '');
                    var has_error_form = $('#' + 'has_error_edit_' + has_error);
                    has_error_form.addClass(val.length > 0 ? 'has-error' : '');

                    el = $('[id="edit_' + key + '_error"]');
                    el.html(val);
                });
                return false;
            }
            mapping_data_transaksi_booking();
            toastr["success"](res.message);
        });
    })

    function btn_hapus_transaksi_booking(id) {
        if (id) {
            Swal.fire({
                title: 'Apa kamu yakin?',
                text: "Data yang sudah dihapus tidak dapat diubah.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Hapus!'
            }).then((result) => {
                if (result.isConfirmed) {
                    ajax_call('transaksi-booking/delete/' + id, 'GET', '', function(response) {
                        var res = response.responseJSON;
                        mapping_data_transaksi_booking();
                        toastr["success"](res.message);
                    });
                }
            })
        } else {
            toastr['error']("ID Transaksi Booking tidak ditemukan.");
        }
    }
</script>