<!-- MAIN -->
<div class="main">
    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- OVERVIEW -->
            <div class="panel panel-headline">
                <div class="panel-heading">
                    <h3 class="panel-title">Transaksi Booking</h3>
                </div>
                <div class="panel-body">
                    <div style="margin-bottom: 10px;">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal_tambah_transaksi_booking">Tambah</button>
                    </div>
                    <div class="alert alert-info alert-dismissible" role="alert">
                        <i class="fa fa-info-circle"></i> Status yang sudah <b>DIBATALKAN</b>, <b>SELESAI</b> dan <b> DALAM PENGERJAAN</b> tidak dapat diubah atau dihapus.
                    </div>
                    <div class="table table-responsive">
                        <table id="tbl_transaksi_booking" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Code Transaksi</th>
                                    <th>Nama Customer</th>
                                    <th>Jenis Layanan</th>
                                    <th>Jenis Kendaraan</th>
                                    <th>Merk Kendaraan</th>
                                    <th>Tipe Kendaraan</th>
                                    <th>No. Polisi</th>
                                    <th>Tanggal Booking</th>
                                    <th>Tanggal Service</th>
                                    <th>Status</th>
                                    <th>Created By</th>
                                    <th>Updated By</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="data_transaksi_booking">
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
            <!-- END OVERVIEW -->
        </div>
    </div>
    <!-- END MAIN CONTENT -->
</div>
<!-- END MAIN -->
<?php $this->load->view('pages/TransaksiBooking/modal/v_modal_add'); ?>
<?php $this->load->view('pages/TransaksiBooking/modal/v_modal_edit'); ?>