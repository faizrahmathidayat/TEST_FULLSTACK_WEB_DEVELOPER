<?php
function admin_template($view, $data = null, $js = null, $title = '')
{
    $ci = get_instance();
    $dataJS['js'] = $js;
    $judul['title'] = $title;
    $ci->load->view('templates/header', $judul);
    $ci->load->view('templates/sidebar');
    $ci->load->view($view, $data);
    $ci->load->view('templates/footer', $dataJS);
}
