<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'AuthController';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['exceptions/401'] = 'ExceptionController/error_401';

// Auth
$route['proses-login'] = 'AuthController/login';
$route['logout'] = 'AuthController/logout';
// end

$route['dashboard'] = 'DashboardController'; //dashboard

// Customer
$route['customer'] = 'CustomerController';
$route['customer/get-data'] = 'CustomerController/getData';
$route['customer/store'] = 'CustomerController/store';
$route['customer/show/(:num)'] = 'CustomerController/show/$1';
$route['customer/update/(:num)'] = 'CustomerController/update/$1';
// end

// Kategori Layanan
$route['kategori-layanan'] = 'KategoriLayananController';
$route['kategori-layanan/get-data'] = 'KategoriLayananController/getData';
$route['kategori-layanan/store'] = 'KategoriLayananController/store';
$route['kategori-layanan/show/(:num)'] = 'KategoriLayananController/show/$1';
$route['kategori-layanan/update/(:num)'] = 'KategoriLayananController/update/$1';
// end

// Jenis Layanan
$route['jenis-layanan'] = 'JenisLayananController';
$route['jenis-layanan/get-data'] = 'JenisLayananController/getData';
$route['jenis-layanan/store'] = 'JenisLayananController/store';
$route['jenis-layanan/show/(:num)'] = 'JenisLayananController/show/$1';
$route['jenis-layanan/update/(:num)'] = 'JenisLayananController/update/$1';
// end

// Transaksi Booking
$route['transaksi-booking'] = 'TransaksiBookingController';
$route['transaksi-booking/get-data'] = 'TransaksiBookingController/getData';
$route['transaksi-booking/store'] = 'TransaksiBookingController/store';
$route['transaksi-booking/show/(:num)'] = 'TransaksiBookingController/show/$1';
$route['transaksi-booking/update/(:num)'] = 'TransaksiBookingController/update/$1';
$route['transaksi-booking/delete/(:num)'] = 'TransaksiBookingController/delete/$1';
// end

// Page Customer Booking
$route['booking'] = 'BookingController';
$route['booking/store'] = 'BookingController/store';
// end

// Page Customer Booking
$route['kelola-pengguna'] = 'KelolaPenggunaController';
$route['kelola-pengguna/get-data'] = 'KelolaPenggunaController/getData';
$route['kelola-pengguna/store'] = 'KelolaPenggunaController/store';
$route['kelola-pengguna/show/(:num)'] = 'KelolaPenggunaController/show/$1';
$route['kelola-pengguna/update/(:num)'] = 'KelolaPenggunaController/update/$1';
$route['kelola-pengguna/delete/(:num)'] = 'KelolaPenggunaController/delete/$1';
// end
